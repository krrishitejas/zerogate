import sqlite3
import os

# --- VULNERABILITY 1: Hardcoded Secrets ---
# Storing credentials directly in the source code is a major security risk.
# If this code is committed to version control, the secret is leaked.
AWS_ACCESS_KEY = "AKIA1234567890EXAMPLE"
DB_PASSWORD = "super_secret_password_123!"

def connect_db():
    # Setup a dummy DB for demonstration
    conn = sqlite3.connect('example.db')
    cursor = conn.cursor()
    cursor.execute('CREATE TABLE IF NOT EXISTS users (username TEXT, bio TEXT)')
    conn.commit()
    return conn

def get_user_bio(username):
    conn = connect_db()
    cursor = conn.cursor()
    
    # --- VULNERABILITY 2: SQL Injection ---
    # Using f-strings or string concatenation to build queries allows attackers
    # to manipulate the SQL logic (e.g., inputting "' OR '1'='1").
    query = f"SELECT bio FROM users WHERE username = '{username}'"
    
    print(f"Executing Query: {query}")
    cursor.execute(query) 
    result = cursor.fetchone()
    conn.close()
    return result

def calculate_discount(price, formula):
    # --- VULNERABILITY 3: Insecure use of eval() ---
    # eval() executes arbitrary code. If a user passes "__import__('os').system('rm -rf /')",
    # the server will execute that command.
    print(f"Applying formula: {formula}")
    discounted_price = eval(formula)
    return discounted_price

# --- Simulating User Input ---
if __name__ == "__main__":
    # 1. SQL Injection Demo
    # User inputs a payload to bypass checks
    user_input = "admin' OR '1'='1" 
    get_user_bio(user_input)

    # 2. Remote Code Execution (RCE) Demo
    # User inputs malicious code instead of a math formula
    malicious_formula = "__import__('os').getcwd()" 
    print("Result:", calculate_discount(100, malicious_formula))